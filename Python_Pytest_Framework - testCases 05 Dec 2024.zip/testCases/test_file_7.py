import time

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By


class Test_7:

    @pytest.mark.web
    @pytest.mark.credkart
    def test_CredKart_Login(self,driver_setup):

        self.driver = driver_setup
        self.driver.get("https://automation.credence.in/login")
        self.driver.maximize_window()

        # Enter the username
        username = self.driver.find_element(By.ID, "email")
        username.send_keys("Credencetest@test.com")

        # Enter the password
        password = self.driver.find_element(By.ID, "password")
        password.send_keys("Credence@1234")

        # Click the login button
        self.driver.find_element(By.CLASS_NAME, "btn").click()

        # Verify that the user is logged in
        try:
            MenuButton = self.driver.find_element(By.CLASS_NAME, "dropdown-toggle")
            assert MenuButton.is_displayed(), "User is not logged in"
            print("User is logged in")
        except:
            print("User is not logged in")

        finally:
            self.driver.quit()

    @pytest.mark.web
    @pytest.mark.OrangeHRM
    def test_OrangeHRM_Login(self, driver_setup):
        self.driver = driver_setup
        ################################################################
        self.driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)  # Wait for 10 seconds for all elements to

        username = self.driver.find_element(By.XPATH, "//input[@placeholder='Username']")
        username.send_keys("Admin")
        password = self.driver.find_element(By.XPATH, "//input[@placeholder='Password']")
        password.send_keys("admin123")

        login_button = self.driver.find_element(By.XPATH, "//button[@type='submit']")
        login_button.click()

        # Verify that the user is logged in

        try:
            menu_button = self.driver.find_element(By.XPATH, "//p[@class='oxd-userdropdown-name']")
            assert menu_button.is_displayed(), "User is not logged in"
            print("User is logged in")
            menu_button.click()
            logout_button = self.driver.find_element(By.XPATH, "//a[normalize-space()='Logout']")
            logout_button.click()
        except:
            print("User is not logged in")

        #time.sleep(10)
        self.driver.quit()
