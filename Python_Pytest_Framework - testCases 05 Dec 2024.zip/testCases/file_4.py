

class Test4:


    def test_Mul_9(self):
        a = 10
        b = 20
        print(f" Multiplication of a and b is {a * b}")
        assert a * b == 200, "Test Failed"



    def test_add_10(self):
        a = 10
        b = 200
        print(f" Addition of a and b is {a + b}")
        assert a + b == 210, "Test Failed"

